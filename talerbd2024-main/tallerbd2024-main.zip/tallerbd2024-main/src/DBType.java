public enum DBType {
    MySql,
    Postgres,
    Oracle
}
