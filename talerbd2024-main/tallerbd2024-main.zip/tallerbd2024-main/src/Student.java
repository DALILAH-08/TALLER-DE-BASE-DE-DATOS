public record Student(String nocontrol, String fullname, String career, String curp, Integer currentgrade ) {
}
