import java.sql.Connection;

public interface IDBAdapter {
    Connection getConnection();
}

